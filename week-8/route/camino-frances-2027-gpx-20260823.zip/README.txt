﻿Camino Frances 2027 - cycling GPX
=================================
Generated: 2026-08-23
Files: 12 daily GPX (1349 KB total)

Saint-Jean-Pied-de-Port to Santiago de Compostela, 782 km over 13 days.
Day 8 is a rest day in Leon, so there is no day08 file.

Each file contains
  - the route as a GPX track, with elevation on every point
  - albergue waypoints (bed icon), thinned: none at the start town where you
    slept, a few along the way for stamps, all of them at the destination
  - photo spots and sights (camera icon), churches (cross), restaurants (fork),
    passes (summit)
  - waypoint names in English, notes in Korean

Loading them
  Garmin    copy the .gpx files to GARMIN\NewFiles\ and restart the device
  Phone     open with OsmAnd, Komoot, Gaia GPS or Garmin Explore
  Editing   gpx.studio, bikerouter.de

Notes
  - Days 2, 10, 11 and 12 use road detours where the walking route is too
    steep or too rough for a loaded bike.
  - Day 1 keeps the Napoleon route over the Pyrenees: 28% climbs and a -33%
    descent. Expect to push. The Valcarlos road alternative is gentler.
  - Surface type is not in GPX. Detours were chosen on gradient, not by
    riding them.

Sources
  Route and facilities: santiago.nl (OpenStreetMap, ODbL)
  Elevation: EU-DEM / Copernicus
  Detours: cycle.travel (OpenStreetMap)
