﻿Camino Frances 2027 - cycling GPX
=================================
Generated: 2026-08-23

Saint-Jean-Pied-de-Port to Santiago de Compostela
782 km, 10,726 m of climbing, 13 days.
Day 8 is a rest day in Leon, so there is no day08 file.

FILES
  camino-2027-dayNN.gpx      route + waypoints, for any app or device
  garmin-courses-tcx\*.tcx   Garmin Edge courses with ride alerts (optional)

WHAT IS IN THE GPX
  - the route as a track, roughly a point every 50 m, elevation on every point
  - waypoints with Garmin icons:
        bed      albergue (147)
        cross    church, monastery, chapel (35)
        camera   photo spot or viewpoint (28)
        fork     restaurant (6)
        summit   pass or high point (5)
  - waypoint names in English, notes in Korean

  Albergues are thinned on purpose: none in the town you started from, a few
  along the way for stamps, all of them at the destination.

LOADING THEM
  Garmin Edge   copy .gpx and .tcx to GARMIN\NewFiles\ and restart the unit.
                The .tcx appears under Navigation > Courses; the .gpx
                waypoints appear as icons on the map.
  Phone         OsmAnd, Komoot, Gaia GPS or Garmin Explore will open the .gpx.
  Editing       gpx.studio or bikerouter.de

GARMIN EDGE - IMPORTANT
  Opening a course may stall at 5% with a warning that the route is too long.
  Turn recalculation off:
      Settings > Activity Profiles > (profile) > Navigation > Routing >
      Recalculation  ->  Off
  The track is already correct, so there is nothing for the unit to recompute.

  Ride alerts come from the .tcx course, not from the .gpx. Start the course
  and the unit announces each course point (about 20 per day) as you approach.
  Titles are in Korean; set the unit language to Korean or they show as boxes.

STAGES
  Day  1  45.8 km  1,741 m   Saint-Jean-Pied-de-Port - Zubiri
  Day  2  68.9 km    944 m   Zubiri - Estella
  Day  3  61.3 km    908 m   Estella - Navarrete
  Day  4  58.7 km    832 m   Navarrete - Belorado
  Day  5  90.0 km    940 m   Belorado - Castrojeriz
  Day  6  82.3 km    516 m   Castrojeriz - Sahagun
  Day  7  54.7 km    261 m   Sahagun - Leon
  Day  8      rest day in Leon
  Day  9  68.9 km    666 m   Leon - Rabanal del Camino
  Day 10  74.3 km    908 m   Rabanal del Camino - Vega de Valcarce
  Day 11  62.3 km  1,067 m   Vega de Valcarce - Sarria
  Day 12  76.3 km  1,337 m   Sarria - Arzua
  Day 13  38.9 km    606 m   Arzua - Santiago de Compostela

BEFORE YOU RIDE
  - Day 1 keeps the Napoleon route over the Pyrenees: a 28% climb and a -33%
    descent. Expect to push the bike up and walk it down. The Valcarlos road
    is the gentler alternative if you would rather not.
  - Days 2, 10, 11 and 12 replace the walking line with paved road where it
    was too steep or too rough for a loaded bike.
  - Surface type does not exist in GPX. The detours were chosen on gradient,
    not by riding them. Check each day on a map before you go.

SOURCES
  Route and facilities: santiago.nl (OpenStreetMap, ODbL), 2026-06-16 edition
  Elevation: EU-DEM / Copernicus
  Detours: cycle.travel (OpenStreetMap)
